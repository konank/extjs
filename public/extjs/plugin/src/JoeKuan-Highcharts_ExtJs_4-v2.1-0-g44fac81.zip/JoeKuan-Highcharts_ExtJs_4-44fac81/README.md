This is the HighCharts extension supports for ExtJs 4.

Click [here] for the tutorial.

Click [here] for the live demo.

[here]: http://joekuan.wordpress.com/highcharts-extjs/tutorial/
[here]: http://www.joekuan.org/demos/Highcharts_ExtJs_4/
