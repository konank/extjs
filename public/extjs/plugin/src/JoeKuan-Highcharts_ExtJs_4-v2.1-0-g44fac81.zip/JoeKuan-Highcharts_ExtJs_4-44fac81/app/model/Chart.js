Ext.define('HighCharts.model.Chart', {
    extend: 'Ext.data.Model',
    fields: ['name']
});