Ext.define('HighCharts.model.Browsers', {
    extend: 'Ext.data.Model',
    fields: ['version', 'vendor', 'usage']
});

