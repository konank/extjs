Ext.define('HighCharts.model.BrowsersJune', {
    extend: 'Ext.data.Model',
    fields: ['browser', '2011_June', '2012_June']
});

