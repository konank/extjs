Ext.define('HighCharts.model.Scatter', {
    extend: 'Ext.data.Model',
    fields: ['points_x', 'points_y', 'rebars_x', 'rebars_y']
});