Ext.define('HighCharts.view.chart.Tree', {
  extend : 'Ext.tree.Panel',
  alias : 'widget.chartsTree',
  store: 'ChartsTree',
  rootVisible: false
});